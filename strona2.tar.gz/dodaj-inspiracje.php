<form id="inspiracjeform" method="post" action="zapisz3.php">
<input type="text" placeholder="NAZWA" name="NAZWA" ></br>
<input placeholder="URL OBRAZKA" type="url" name="homepage"></br>
<textarea placeholder="PRZEPIS/OPIS" name="TEXT1" cols="40" rows="5"></textarea></br>
<button onclick="return sprawdz_powitaj3()">DODAJ</button></br>
</form>
