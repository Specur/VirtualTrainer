<form id="cwiczeniaform" method="post" action="zapisz2.php">
<input type="text" placeholder="NAZWA_CWICZENIE" name="NAZWA" ></br>
<input type="number" placeholder="TRUDNOŚĆ" name="TRUDNOSC" ></br>
<input type="text" placeholder="CZĘŚĆ CIAŁA" name="CZESC_CIALA" ></br>
<textarea placeholder="OPIS" cols="50" rows="3" name="TEXT1"></textarea></br>
<button onclick="return sprawdz_powitaj2()">DODAJ</button></br>
</form>
