

<form id="produktform" method="post" action="zapiszz.php">

<input type="text" placeholder="NAZWA" name="NAZWA_PRODUKT"  onfocus="this.placeholder=''" onblur="this.placeholder='Nazwa'" ></br>

<input type="number" placeholder="KCL" name="KCL"  onfocus="this.placeholder=''" onblur="this.placeholder='KCL'" ></br>

<input type="number" placeholder="Węglowodany" name="WEGLOWODANY" onfocus="this.placeholder=''" onblur="this.placeholder='Węglowodany'" ></br>

<input type="number" placeholder="Białko" name="BIALKO"  onfocus="this.placeholder=''" onblur="this.placeholder='Białko'" ></br>

<input type="number" placeholder="Tłuszcz" name="TLUSZCZ" onfocus="this.placeholder=''" onblur="this.placeholder='Tłuszcz'" ></br>

<button onclick="return sprawdz_powitaj()">DODAJ</button>

</form>














